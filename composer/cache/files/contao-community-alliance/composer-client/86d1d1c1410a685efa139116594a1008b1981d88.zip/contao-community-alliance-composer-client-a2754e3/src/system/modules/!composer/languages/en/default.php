<?php

$GLOBALS['TL_LANG']['MSG']['disabled_by_composer'] = '(disabled by Composer Client)';
