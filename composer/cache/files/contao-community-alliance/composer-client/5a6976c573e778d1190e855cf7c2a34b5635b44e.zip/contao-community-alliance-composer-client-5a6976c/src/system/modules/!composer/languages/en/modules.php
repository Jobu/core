<?php

/**
 * Back end modules
 */
$GLOBALS['TL_LANG']['MOD']['composer'] = array('Package management', 'Install and manage packages');
