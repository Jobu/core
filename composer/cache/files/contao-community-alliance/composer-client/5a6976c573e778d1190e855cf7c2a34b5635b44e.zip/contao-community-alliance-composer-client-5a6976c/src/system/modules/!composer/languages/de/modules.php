<?php

/**
 * Back end modules
 */

$GLOBALS['TL_LANG']['MOD']['composer']['0'] = 'Paketverwaltung';
$GLOBALS['TL_LANG']['MOD']['composer']['1'] = 'Pakete installieren und verwalten';

