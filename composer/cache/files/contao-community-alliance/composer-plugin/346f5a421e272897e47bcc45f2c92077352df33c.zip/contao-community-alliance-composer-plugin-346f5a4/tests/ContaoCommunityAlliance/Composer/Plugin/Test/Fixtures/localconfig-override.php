<?php

$GLOBALS['TL_CONFIG']['websiteTitle']   = 'Contao Open Source CMS';

$GLOBALS['TL_CONFIG']['websiteTitle']   = 'Overridden';
