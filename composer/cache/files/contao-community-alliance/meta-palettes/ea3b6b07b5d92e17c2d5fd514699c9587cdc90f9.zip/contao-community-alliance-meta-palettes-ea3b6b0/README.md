# MetaPalettes

Allow dynamic configuration of the contao dca with array, instead of a long string.
