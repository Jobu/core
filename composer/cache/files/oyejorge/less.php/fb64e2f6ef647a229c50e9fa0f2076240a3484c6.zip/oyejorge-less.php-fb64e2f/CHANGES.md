This is where the changelog will go for 1.7.0.9 or higher now.

# 1.7.0.9

 - Remove space at beginning of Version.php
 - Revert require() paths in test interface