<?php

/**
 * @package   contao-bootstrap
 * @author    David Molineus <david.molineus@netzmacht.de>
 * @license   LGPL 3+
 * @copyright 2013-2015 netzmacht creative David Molineus
 */


TemplateLoader::addFiles(
    array (
        'ce_bootstrap_tab' => 'system/modules/bootstrap-tab/templates',
    )
);
