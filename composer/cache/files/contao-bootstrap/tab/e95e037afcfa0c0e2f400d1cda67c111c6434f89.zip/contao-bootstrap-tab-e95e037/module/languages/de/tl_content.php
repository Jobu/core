<?php

$GLOBALS['TL_LANG']['tl_content']['bootstrap_tabs'][0]               = 'Tabs';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_tabs'][1]               = 'Definieren Sie die einzelnen Tab-Bezeichnungen. Es können auch Dropdown-Menüs angelegt werden.';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_tabs_title'][0]         = 'Bezeichung';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_tabs_title'][1]         = 'Die Bezeichnung wird für das Tab-Menü verwendet.';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_tabs_type'][0]          = 'Dropdown';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_tabs_type'][1]          = 'Der Eintrag kann als Dropdown-Menü erstellt werden. Die nachfolgenden Elemente müssen kann als Kind definiert werden.';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_tabs_type']['dropdown'] = 'Dropdown-Menü';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_tabs_type']['child']    = 'Kind-Element';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_fade'][0]               = 'Überblendeffekt aktivieren';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_fade'][1]               = 'Verwendet einen Überblendeffekt beim Wechseln der Tabs.';
