<?php

/*
 * Labels
 */
$GLOBALS['TL_LANG']['CTE']['bootstrap_tabs']     = 'Reiter-Elemente';

/*
 * content elements
 */
$GLOBALS['TL_LANG']['CTE']['bootstrap_tabStart'][0] = 'Reiter Start';
$GLOBALS['TL_LANG']['CTE']['bootstrap_tabStart'][1] = 'Beginnt die Tab-Komponente.';
$GLOBALS['TL_LANG']['CTE']['bootstrap_tabPart'][0]  = 'Reiter Trennelement';
$GLOBALS['TL_LANG']['CTE']['bootstrap_tabPart'][1]  = 'Trennelement um einen neuen Tab anzufangen';
$GLOBALS['TL_LANG']['CTE']['bootstrap_tabEnd'][0]   = 'Reiter Ende';
$GLOBALS['TL_LANG']['CTE']['bootstrap_tabEnd'][1]   = 'Tab-Komponente beenden';
