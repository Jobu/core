<?php

$GLOBALS['TL_LANG']['tl_content']['bootstrap_tabs'][0]               = 'Tabs';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_tabs'][1]               = 'Define each tab label. Dropdown menus can be set too.';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_tabs_title'][0]         = 'Title';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_tabs_title'][1]         = 'The title will be used fot the tab menu.';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_tabs_type'][0]          = 'Dropdown';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_tabs_type'][1]          = 'Entry can be created as a dropdown menu. The following elements have to be defined as a child.';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_tabs_type']['dropdown'] = 'Dropdown menu';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_tabs_type']['child']    = 'Child elements';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_fade'][0]               = 'Enable fading';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_fade'][1]               = 'Uses a fading effect with changing tabs.';
