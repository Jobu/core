<?php

$GLOBALS['TL_LANG']['MOD']['bootstrap-tab'][0] = 'Bootstrap Tab';
$GLOBALS['TL_LANG']['MOD']['bootstrap-tab'][1] = 'Bootstraps Tab Komponente';
