<?php

/*
 * Labels
 */
$GLOBALS['TL_LANG']['CTE']['bootstrap_tabs']     = 'Tab elements';

/*
 * content elements
 */
$GLOBALS['TL_LANG']['CTE']['bootstrap_tabStart'][0] = 'Tab Start';
$GLOBALS['TL_LANG']['CTE']['bootstrap_tabStart'][1] = 'Starts a Tab-element.';
$GLOBALS['TL_LANG']['CTE']['bootstrap_tabPart'][0]  = 'Tab part-element';
$GLOBALS['TL_LANG']['CTE']['bootstrap_tabPart'][1]  = 'Part-element to separate parts of a Bootstrap Carousel';
$GLOBALS['TL_LANG']['CTE']['bootstrap_tabEnd'][0]   = 'Tab end';
$GLOBALS['TL_LANG']['CTE']['bootstrap_tabEnd'][1]   = 'End-element of the Bootstrap Tab';
