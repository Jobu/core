Contao-Bootstrap Tab Component
==============================

[![Build Status](http://img.shields.io/travis/contao-bootstrap/tab/master.svg?style=flat-square)](https://travis-ci.org/contao-bootstrap/tab)
[![Version](http://img.shields.io/packagist/v/contao-bootstrap/tab.svg?style=flat-square)](http://packagist.com/packages/contao-bootstrap/tab)
[![License](http://img.shields.io/packagist/l/contao-bootstrap/tab.svg?style=flat-square)](http://packagist.com/packages/contao-bootstrap/tab)
[![Downloads](http://img.shields.io/packagist/dt/contao-bootstrap/tab.svg?style=flat-square)](http://packagist.com/packages/contao-bootstrap/tab)
[![Contao Community Alliance coding standard](http://img.shields.io/badge/cca-coding_standard-red.svg?style=flat-square)](https://github.com/contao-community-alliance/coding-standard)

This extension provides Bootstrap integration into Contao. 

Contao-Bootstrap is a modular integration. This extension adds the Bootstrap Tab component as content element to Contao.
