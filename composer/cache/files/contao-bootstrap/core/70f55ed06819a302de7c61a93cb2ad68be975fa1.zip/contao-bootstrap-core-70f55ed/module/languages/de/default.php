<?php

/**
 * content elements
 */

$GLOBALS['TL_LANG']['CTE']['bootstrap']             = 'Bootstrap';
$GLOBALS['TL_LANG']['ERR']['wrapperStartNotExists'] = 'Das zugehörige Startelement für "%s" wurde nicht gefunden. Bitte legen Sie dieses erst an.';
$GLOBALS['TL_LANG']['bootstrapConfig']['0']         = 'Bootstrap-Konfiguration';
$GLOBALS['TL_LANG']['bootstrapConfig']['1']         = 'Bearbeiten Sie die Bootstrap-Konfiguration.';

