<?php

$GLOBALS['TL_LANG']['tl_theme']['bootstrap_config'][0] = 'Bootstrap configuration';
$GLOBALS['TL_LANG']['tl_theme']['bootstrap_config'][1] = 'Edit Bootstrap configuration';