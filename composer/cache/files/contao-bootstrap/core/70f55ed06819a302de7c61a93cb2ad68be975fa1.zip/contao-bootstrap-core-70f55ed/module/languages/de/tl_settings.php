<?php

$GLOBALS['TL_LANG']['tl_settings']['bootstrap_legend'] = 'Bootstrap';

$GLOBALS['TL_LANG']['tl_settings']['bootstrapIconSet'][0] = 'Icon Set';
$GLOBALS['TL_LANG']['tl_settings']['bootstrapIconSet'][1] = 'Auswahl des Icon Sets.';