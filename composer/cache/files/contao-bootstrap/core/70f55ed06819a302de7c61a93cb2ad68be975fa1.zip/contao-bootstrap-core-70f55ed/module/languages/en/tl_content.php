<?php

/**
 * legends
 */
$GLOBALS['TL_LANG']['tl_content']['config_legend'] = 'Configuration';

$GLOBALS['TL_LANG']['tl_content']['bootstrap_dataAttributes'][0]       = 'Data attributes';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_dataAttributes'][1]       = 'With data attributes Bootstrap components can be triggered, such as a modal window.';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_dataAttributes_name'][0]  = 'Name';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_dataAttributes_name'][1]  = 'Name of the attribute';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_dataAttributes_value'][0] = 'Value';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_dataAttributes_value'][1] = 'Value of the attribute';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_icon'][0]                 = 'Icon';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_icon'][1]                 = 'Select an icon.';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_parentId'][0]             = 'Parent wrapper element';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_parentId'][1]             = 'This wrapper elements belongs to a parent start element.';

$GLOBALS['TL_LANG']['tl_content']['fixBootstrapParent'] = 'No parent selected after duplicating element. Fix it now.';
