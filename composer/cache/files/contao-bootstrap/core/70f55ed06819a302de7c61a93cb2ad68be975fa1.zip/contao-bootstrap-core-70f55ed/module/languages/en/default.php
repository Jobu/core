<?php

/*
 * Eontent elements
 */
$GLOBALS['TL_LANG']['CTE']['bootstrap'] = 'Bootstrap';

/*
 * Errors
 */
$GLOBALS['TL_LANG']['ERR']['wrapperStartNotExists'] = 'The related start-element of "%s" could not be found. Please set it up first.';

/*
 * Bootstrap config menu entry
 */
$GLOBALS['TL_LANG']['bootstrapConfig'][0] = 'Bootstrap configuration';
$GLOBALS['TL_LANG']['bootstrapConfig'][1] = 'Edit Bootstrap configuration';
