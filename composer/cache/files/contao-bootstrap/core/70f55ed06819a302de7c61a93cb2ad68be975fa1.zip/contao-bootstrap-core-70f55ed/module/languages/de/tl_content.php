<?php

/**
 * legends
 */
$GLOBALS['TL_LANG']['tl_content']['config_legend'] = 'Konfiguration';

$GLOBALS['TL_LANG']['tl_content']['bootstrap_dataAttributes'][0]       = 'Data-Attribute';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_dataAttributes'][1]       = 'Über Data-Attribute können Bootstrap Komponenten angesteuert werden, wie z.B. ein modales Fenster.';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_dataAttributes_name'][0]  = 'Name';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_dataAttributes_name'][1]  = 'Name des Attributes';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_dataAttributes_value'][0] = 'Wert';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_dataAttributes_value'][1] = 'Wert des Attributes';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_icon'][0]                 = 'Icon';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_icon'][1]                 = 'Ein Icon auswählen.';
