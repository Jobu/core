<?php

$GLOBALS['TL_LANG']['tl_settings']['bootstrap_legend'] = 'Bootstrap';

$GLOBALS['TL_LANG']['tl_settings']['bootstrapIconSet'][0] = 'Icon set';
$GLOBALS['TL_LANG']['tl_settings']['bootstrapIconSet'][1] = 'Please choose an icon set which Bootstrap will use.';
