<?php

/**
 * legends
 */
$GLOBALS['TL_LANG']['tl_layout']['layoutTypes']['bootstrap'][0] = 'Bootstrap';
$GLOBALS['TL_LANG']['tl_layout']['layoutTypes']['bootstrap'][1] = 'Layout basiert auf Contao-Bootstrap';
$GLOBALS['TL_LANG']['tl_layout']['layoutTypes']['default'][0]   = 'Contao Standard';
$GLOBALS['TL_LANG']['tl_layout']['layoutTypes']['default'][1]   = 'Gewöhnliches Layout von Contao';


/**
 * fields
 */
$GLOBALS['TL_LANG']['tl_layout']['layoutType'][0] = 'Typ des Layouts';
$GLOBALS['TL_LANG']['tl_layout']['layoutType'][1] = 'Bitte wählen Sie den Typ des Layouts';