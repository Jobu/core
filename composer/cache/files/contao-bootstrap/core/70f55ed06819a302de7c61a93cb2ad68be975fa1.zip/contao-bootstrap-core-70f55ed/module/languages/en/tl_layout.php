<?php

/**
 * legends
 */
$GLOBALS['TL_LANG']['tl_layout']['layoutTypes']['bootstrap'][0] = 'Bootstrap';
$GLOBALS['TL_LANG']['tl_layout']['layoutTypes']['bootstrap'][1] = 'Layout based on contao-Bootstrap';
$GLOBALS['TL_LANG']['tl_layout']['layoutTypes']['default'][0]   = 'Contao standard';
$GLOBALS['TL_LANG']['tl_layout']['layoutTypes']['default'][1]   = 'Common contao layout';


/**
 * fields
 */
$GLOBALS['TL_LANG']['tl_layout']['layoutType'][0] = 'Layout type';
$GLOBALS['TL_LANG']['tl_layout']['layoutType'][1] = 'Please select the type of layout';
