<?php

/*
 * Labels
 */
$GLOBALS['TL_LANG']['CTE']['bootstrap_carousel'] = 'Carousel-Element';
$GLOBALS['TL_LANG']['MSC']['bootstrap_carousel'] = 'Bootstrap Carousel: %s';

/*
 * content elements
 */
$GLOBALS['TL_LANG']['CTE']['bootstrap_carouselStart'][0]       = 'Carousel Start';
$GLOBALS['TL_LANG']['CTE']['bootstrap_carouselStart'][1]       = 'Beginnt ein Bootstrap Carousel.';
$GLOBALS['TL_LANG']['CTE']['bootstrap_carouselPart'][0]        = 'Carousel Trennelement';
$GLOBALS['TL_LANG']['CTE']['bootstrap_carouselPart'][1]        = 'Trennelement für das Bootstrap Carousel.';
$GLOBALS['TL_LANG']['CTE']['bootstrap_carouselEnd'][0]         = 'Carousel Ende';
$GLOBALS['TL_LANG']['CTE']['bootstrap_carouselEnd'][1]         = 'Ende des Bootstrap Carousel.';
