<?php

$GLOBALS['TL_LANG']['tl_content']['bootstrap_showIndicators'][0] = 'Show indicators';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_showIndicators'][1] = 'Indicators of the current slider element will be displayed';

$GLOBALS['TL_LANG']['tl_content']['bootstrap_showControls'][0] = 'Show controls';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_showControls'][1] = 'Left/right buttons are displayed.';

$GLOBALS['TL_LANG']['tl_content']['bootstrap_autostart'][0] = 'Austostart';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_autostart'][1] = 'Animation of the elements start atomatically.';

$GLOBALS['TL_LANG']['tl_content']['bootstrap_interval'][0] = 'Display interval';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_interval'][1] = 'Display duration in milliseconds of an element.';

$GLOBALS['TL_LANG']['tl_content']['bootstrap_tabs'][0] = 'Tabs';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_tabs'][1] = 'Define each tab label. Dropdown menus can be set too.';
