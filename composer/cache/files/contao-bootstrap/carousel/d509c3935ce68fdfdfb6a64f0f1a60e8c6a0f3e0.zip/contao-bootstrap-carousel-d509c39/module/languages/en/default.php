<?php

/*
 * Labels
 */
$GLOBALS['TL_LANG']['CTE']['bootstrap_carousel'] = 'Carousel elements';
$GLOBALS['TL_LANG']['MSC']['bootstrap_carousel'] = 'Bootstrap Carousel: %s';

/*
 * content elements
 */
$GLOBALS['TL_LANG']['CTE']['bootstrap_carouselStart'][0]       = 'Carousel Start';
$GLOBALS['TL_LANG']['CTE']['bootstrap_carouselStart'][1]       = 'Starts a bootstrap carousel.';
$GLOBALS['TL_LANG']['CTE']['bootstrap_carouselPart'][0]        = 'Carousel part-element';
$GLOBALS['TL_LANG']['CTE']['bootstrap_carouselPart'][1]        = 'Part-element separates parts of the Bootstrap Carousel.';
$GLOBALS['TL_LANG']['CTE']['bootstrap_carouselEnd'][0]         = 'Carousel end-element';
$GLOBALS['TL_LANG']['CTE']['bootstrap_carouselEnd'][1]         = 'End-element of the Bootstrap Carousel.';
