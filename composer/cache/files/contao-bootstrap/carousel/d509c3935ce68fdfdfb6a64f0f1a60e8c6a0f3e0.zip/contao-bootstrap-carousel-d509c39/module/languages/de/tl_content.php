<?php

$GLOBALS['TL_LANG']['tl_content']['bootstrap_showIndicators'][0] = 'Indikatoren anzeigen';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_showIndicators'][1] = 'Indikatoren des aktuellen Slider-Elements werden eingeblendet';

$GLOBALS['TL_LANG']['tl_content']['bootstrap_showControls'][0] = 'Steuerelemente anzeigen';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_showControls'][1] = 'Rechts/Link Schaltflächen werden anzeigt.';

$GLOBALS['TL_LANG']['tl_content']['bootstrap_autostart'][0] = 'Automatisch abspielen';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_autostart'][1] = 'Animation des Elements werden automatisch gestartet.';

$GLOBALS['TL_LANG']['tl_content']['bootstrap_interval'][0] = 'Anzeigedauer';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_interval'][1] = 'Anzeigedauer in Millisekunden des einzelnen Elements.';
