Contao-Bootstrap Carousel
=========================

[![Build Status](http://img.shields.io/travis/contao-bootstrap/carousel/master.svg?style=flat-square)](https://travis-ci.org/contao-bootstrap/carousel)
[![Version](http://img.shields.io/packagist/v/contao-bootstrap/carousel.svg?style=flat-square)](http://packagist.com/packages/contao-bootstrap/carousel)
[![License](http://img.shields.io/packagist/l/contao-bootstrap/carousel.svg?style=flat-square)](http://packagist.com/packages/contao-bootstrap/carousel)
[![Downloads](http://img.shields.io/packagist/dt/contao-bootstrap/carousel.svg?style=flat-square)](http://packagist.com/packages/contao-bootstrap/carousel)
[![Contao Community Alliance coding standard](http://img.shields.io/badge/cca-coding_standard-red.svg?style=flat-square)](https://github.com/contao-community-alliance/coding-standard)

This extension provides Bootstrap integration into Contao. 

Contao-Bootstrap is a modular integration. The carousel module provides an content element based on Bootstrap carousel
component.
