<?php

$GLOBALS['TL_LANG']['FMD']['bootstrap_navbar'][0] = 'Navigation bar (Bootstrap)';
$GLOBALS['TL_LANG']['FMD']['bootstrap_navbar'][1] = 'Bootstraps navbar element';
