Contao-Bootstrap Navigation
===========================

[![Build Status](http://img.shields.io/travis/contao-bootstrap/navigation/master.svg?style=flat-square)](https://travis-ci.org/contao-bootstrap/navigation)
[![Version](http://img.shields.io/packagist/v/contao-bootstrap/navigation.svg?style=flat-square)](http://packagist.com/packages/contao-bootstrap/navigation)
[![License](http://img.shields.io/packagist/l/contao-bootstrap/navigation.svg?style=flat-square)](http://packagist.com/packages/contao-bootstrap/navigation)
[![Downloads](http://img.shields.io/packagist/dt/contao-bootstrap/navigation.svg?style=flat-square)](http://packagist.com/packages/contao-bootstrap/navigation)
[![Contao Community Alliance coding standard](http://img.shields.io/badge/cca-coding_standard-red.svg?style=flat-square)](https://github.com/contao-community-alliance/coding-standard)

This extension provides Bootstrap integration into Contao. 

Contao-Bootstrap is a modular integration. The components provides navigation features of the Bootstrap component.

Frontend modules
 * Navbar element
 
Templates
 * Dropdown templates for quicknav and quicklink navigation
 * Navigation dropdown template
