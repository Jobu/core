<?php

$GLOBALS['TL_LANG']['tl_form']['tableless'][0] = 'Kein horizontales Formular';
$GLOBALS['TL_LANG']['tl_form']['tableless'][1] = 'Das Formular nicht als horizontales Formular (Bootstrap) / HTML-Tabellen (Contao) darstellen.';
