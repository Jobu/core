(function($) {
    $(document).ready(function() {
        $('.selectpicker').selectpicker();
    });
})(jQuery);
