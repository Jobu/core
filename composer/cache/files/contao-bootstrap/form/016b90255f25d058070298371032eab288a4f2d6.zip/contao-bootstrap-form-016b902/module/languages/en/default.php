<?php

$GLOBALS['TL_LANG']['MSC']['bootstrapUploadButton'] = 'Choose file';