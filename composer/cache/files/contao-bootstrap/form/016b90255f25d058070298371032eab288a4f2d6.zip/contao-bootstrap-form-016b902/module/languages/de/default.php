<?php

$GLOBALS['TL_LANG']['MSC']['bootstrapUploadButton'] = 'Datei auswählen';
