<?php

$GLOBALS['TL_LANG']['tl_form']['tableless'][0] = 'Disable horizontal form';
$GLOBALS['TL_LANG']['tl_form']['tableless'][1] = 'Do not display form as horizontal form (Bootstrap) / with HTML tables (Contao).';
