Contao-Bootstrap Tab Component
==============================

[![Build Status](http://img.shields.io/travis/contao-bootstrap/form/master.svg?style=flat-square)](https://travis-ci.org/contao-bootstrap/form)
[![Version](http://img.shields.io/packagist/v/contao-bootstrap/form.svg?style=flat-square)](http://packagist.com/packages/contao-bootstrap/form)
[![License](http://img.shields.io/packagist/l/contao-bootstrap/form.svg?style=flat-square)](http://packagist.com/packages/contao-bootstrap/form)
[![Downloads](http://img.shields.io/packagist/dt/contao-bootstrap/form.svg?style=flat-square)](http://packagist.com/packages/contao-bootstrap/form)
[![Contao Community Alliance coding standard](http://img.shields.io/badge/cca-coding_standard-red.svg?style=flat-square)](https://github.com/contao-community-alliance/coding-standard)

This extension provides Bootstrap integration into Contao. 

Contao-Bootstrap is a modular integration. 
This extension provides Bootstrap form styles for Contao frontend widgets which are mainly used by the form generator.
