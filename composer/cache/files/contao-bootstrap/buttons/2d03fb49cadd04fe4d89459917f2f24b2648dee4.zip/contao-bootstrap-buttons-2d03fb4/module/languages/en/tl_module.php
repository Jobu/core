<?php

/**
 * fields
 */
$GLOBALS['TL_LANG']['tl_module']['bootstrap_buttons'][0]                = 'Buttons';
$GLOBALS['TL_LANG']['tl_module']['bootstrap_buttons'][1]                = 'Here you can put in buttons. Both groups of buttons and dropdown lists are possible.';
$GLOBALS['TL_LANG']['tl_module']['bootstrap_buttons_type'][0]           = 'Type';
$GLOBALS['TL_LANG']['tl_module']['bootstrap_buttons_type'][1]           = 'Type of button';
$GLOBALS['TL_LANG']['tl_module']['bootstrap_buttons_label'][0]          = 'Label';
$GLOBALS['TL_LANG']['tl_module']['bootstrap_buttons_label'][1]          = 'Label of the button.';
$GLOBALS['TL_LANG']['tl_module']['bootstrap_buttons_url'][0]            = 'Link address';
$GLOBALS['TL_LANG']['tl_module']['bootstrap_buttons_url'][1]            = 'Enter URL of button link.';
$GLOBALS['TL_LANG']['tl_module']['bootstrap_buttons_attributes'][0]     = 'HTML attribute';
$GLOBALS['TL_LANG']['tl_module']['bootstrap_buttons_attributes'][1]     = 'Define more HTML attributes.';
