<?php

/*
 * Labels
 */
$GLOBALS['TL_LANG']['CTE']['bootstrap_button'][0] = 'Button';
$GLOBALS['TL_LANG']['CTE']['bootstrap_button'][1] = 'Allocates a button as a content element.';
$GLOBALS['TL_LANG']['CTE']['bootstrap_buttons'][0] = 'Combined buttons ';
$GLOBALS['TL_LANG']['CTE']['bootstrap_buttons'][1] = 'Element for combined buttons like toolbars/groups/dropdowns.';
