<?php

/*
 * Labels
 */
$GLOBALS['TL_LANG']['CTE']['bootstrap_button'][0]  = 'Schaltfläche';
$GLOBALS['TL_LANG']['CTE']['bootstrap_button'][1]  = 'Stellt eine Schaltfläche als Inhaltselement zur Verfügung.';
$GLOBALS['TL_LANG']['CTE']['bootstrap_buttons'][0] = 'Kombinierte Schaltfächen ';
$GLOBALS['TL_LANG']['CTE']['bootstrap_buttons'][1] = 'Element für kombinierte Schaltflächen wie Toolbars/Gruppes/Dropdowns';
