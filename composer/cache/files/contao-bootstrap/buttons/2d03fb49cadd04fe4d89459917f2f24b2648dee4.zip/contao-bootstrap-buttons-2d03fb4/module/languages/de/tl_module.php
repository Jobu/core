<?php

/**
 * fields
 */
$GLOBALS['TL_LANG']['tl_module']['bootstrap_buttons_attributes_name']  = 'Attribut';
$GLOBALS['TL_LANG']['tl_module']['bootstrap_buttons_attributes_value'] = 'Wert';
$GLOBALS['TL_LANG']['tl_module']['bootstrap_buttons'][0]               = 'Schaltflächen';
$GLOBALS['TL_LANG']['tl_module']['bootstrap_buttons'][1]               = 'Hier können Sie Schaltflächen anlegen. Sowohl die Gruppierung von Schaltflächen als auch Dropdown-Listen sind möglich.';
$GLOBALS['TL_LANG']['tl_module']['bootstrap_buttons_type'][0]          = 'Typ';
$GLOBALS['TL_LANG']['tl_module']['bootstrap_buttons_type'][1]          = 'Art der Schaltfläche';
$GLOBALS['TL_LANG']['tl_module']['bootstrap_buttons_label'][0]         = 'Beschriftung';
$GLOBALS['TL_LANG']['tl_module']['bootstrap_buttons_label'][1]         = 'Beschriftung der Schaltfläche.';
$GLOBALS['TL_LANG']['tl_module']['bootstrap_buttons_url'][0]           = 'Link-Adresse';
$GLOBALS['TL_LANG']['tl_module']['bootstrap_buttons_url'][1]           = 'Worauf soll die Schaltfläche verlinken.';
$GLOBALS['TL_LANG']['tl_module']['bootstrap_buttons_attributes'][0]    = 'HTML Attribute';
$GLOBALS['TL_LANG']['tl_module']['bootstrap_buttons_attributes'][1]    = 'Weitere HTML-Attribute definieren.';
