<?php

/**
 * @package   contao-bootstrap
 * @author    David Molineus <david.molineus@netzmacht.de>
 * @license   LGPL 3+
 * @copyright 2013-2015 netzmacht creative David Molineus
 */

// Content elements
$GLOBALS['TL_CTE']['links']['bootstrap_button']  = 'Netzmacht\Bootstrap\Buttons\ContentElement\ButtonElement';
$GLOBALS['TL_CTE']['links']['bootstrap_buttons'] = 'Netzmacht\Bootstrap\Buttons\ContentElement\ButtonsElement';
