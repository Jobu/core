<?php

$GLOBALS['TL_LANG']['MOD'][0] = 'Contao-Bootstrap Templates';
$GLOBALS['TL_LANG']['MOD'][1] = 'Contao-Bootstrap Templates Component';