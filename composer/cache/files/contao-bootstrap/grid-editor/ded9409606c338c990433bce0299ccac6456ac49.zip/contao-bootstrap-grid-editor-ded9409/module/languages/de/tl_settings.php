<?php

$GLOBALS['TL_LANG']['tl_settings']['bootstrap_gridColumns'][0] = 'Spaltenanzahl des Gridsystems';
$GLOBALS['TL_LANG']['tl_settings']['bootstrap_gridColumns'][1] = 'Definieren Sie die Anzahl, wieviel Spalten im Spaltenset-Editor zur Verfügung stehen';