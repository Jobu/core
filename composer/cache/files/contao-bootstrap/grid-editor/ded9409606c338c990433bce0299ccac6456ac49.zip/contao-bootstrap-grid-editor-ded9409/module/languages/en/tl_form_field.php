<?php

/**
 * @package   netzmacht-columnset
 * @author    David Molineus <http://www.netzmacht.de>
 * @license   GNU/LGPL
 * @copyright Copyright 2012 David Molineus netzmacht creative
 *
 **/


// change label of sc_type
$GLOBALS['TL_LANG']['tl_form_field']['fsc_type'][0] = 'Sub columns';
$GLOBALS['TL_LANG']['tl_form_field']['fsc_type'][1] = 'Parelease choose how many columns are created';

$GLOBALS['TL_LANG']['tl_form_field']['bootstrap_grid'][0] = 'Column set';
$GLOBALS['TL_LANG']['tl_form_field']['bootstrap_grid'][1] = 'Please choose a defined column set.';
