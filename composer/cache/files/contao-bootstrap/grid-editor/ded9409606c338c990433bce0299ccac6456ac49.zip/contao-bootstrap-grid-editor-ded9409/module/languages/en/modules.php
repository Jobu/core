<?php

/**
 * @package   netzmacht-columnset
 * @author    David Molineus <http://www.netzmacht.de>
 * @license   GNU/LGPL
 * @copyright Copyright 2012 David Molineus netzmacht creative
 *
 **/

$GLOBALS['TL_LANG']['MOD']['columnset'][0] = 'Column sets';
$GLOBALS['TL_LANG']['MOD']['columnset'][1] = 'Define multiple column sets';
