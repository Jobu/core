<?php

/**
 * @package   netzmacht-columnset
 * @author    David Molineus <http://www.netzmacht.de>
 * @license   GNU/LGPL
 * @copyright Copyright 2012 David Molineus netzmacht creative
 *
 **/


$GLOBALS['TL_LANG']['tl_module']['columnset_id'][0] = 'Column set';
$GLOBALS['TL_LANG']['tl_module']['columnset_id'][1] = 'Please choose a defined column set.';
