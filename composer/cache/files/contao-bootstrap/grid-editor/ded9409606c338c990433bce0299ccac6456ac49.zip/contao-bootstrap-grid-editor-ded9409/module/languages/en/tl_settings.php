<?php

$GLOBALS['TL_LANG']['tl_settings']['bootstrap_gridColumns'][0] = 'Number of grid columns';
$GLOBALS['TL_LANG']['tl_settings']['bootstrap_gridColumns'][1] = 'Please define how many columns are available in the grid editor.';