Contao-Bootstrap Grid editor
===========================

[![Build Status](http://img.shields.io/travis/contao-bootstrap/grid-editor/master.svg?style=flat-square)](https://travis-ci.org/contao-bootstrap/grid-editor)
[![Version](http://img.shields.io/packagist/v/contao-bootstrap/grid-editor.svg?style=flat-square)](http://packagist.com/packages/contao-bootstrap/grid-editor)
[![License](http://img.shields.io/packagist/l/contao-bootstrap/grid-editor.svg?style=flat-square)](http://packagist.com/packages/contao-bootstrap/grid-editor)
[![Downloads](http://img.shields.io/packagist/dt/contao-bootstrap/grid-editor.svg?style=flat-square)](http://packagist.com/packages/contao-bootstrap/grid-editor)
[![Contao Community Alliance coding standard](http://img.shields.io/badge/cca-coding_standard-red.svg?style=flat-square)](https://github.com/contao-community-alliance/coding-standard)

This extension is a grid editor based on the Bootstrap grid for the CMS Contao.
 
It provides three integrations
 * felixpfeiffer/subcolumns
 * menatwork/semantic_html5
 * InsertTag {{grid}}
