<?php

$GLOBALS['TL_LANG']['FMD']['bootstrap_modal'][0] = 'Modales Fenster (Bootstrap)';
$GLOBALS['TL_LANG']['FMD']['bootstrap_modal'][1] = 'Bootstraps Modales Fenster';
