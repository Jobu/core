<?php

$GLOBALS['TL_LANG']['bootstrap_config_type']['modal'][0] = 'Modal';
$GLOBALS['TL_LANG']['bootstrap_config_type']['modal'][1] = 'Modal frontend module.';

$GLOBALS['TL_LANG']['tl_bootstrap_config']['modal_adjustForm'][0] = 'Adjust form';
$GLOBALS['TL_LANG']['tl_bootstrap_config']['modal_adjustForm'][1] = 'Form elements are adjusted so that buttons are displayed in the footer.';
$GLOBALS['TL_LANG']['tl_bootstrap_config']['modal_dismiss'][0]    = 'Close button';
$GLOBALS['TL_LANG']['tl_bootstrap_config']['modal_dismiss'][1]    = 'HTML snippet for the dismiss button.';
