<?php

$GLOBALS['TL_LANG']['FMD']['bootstrap_modal'][0] = 'Modal Window (Bootstrap)';
$GLOBALS['TL_LANG']['FMD']['bootstrap_modal'][1] = 'Bootstraps modal window';
