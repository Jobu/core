Contao-Bootstrap Modal Component
=====================

[![Build Status](http://img.shields.io/travis/contao-bootstrap/modal/master.svg?style=flat-square)](https://travis-ci.org/contao-bootstrap/modal)
[![Version](http://img.shields.io/packagist/v/contao-bootstrap/modal.svg?style=flat-square)](http://packagist.com/packages/contao-bootstrap/modal)
[![License](http://img.shields.io/packagist/l/contao-bootstrap/modal.svg?style=flat-square)](http://packagist.com/packages/contao-bootstrap/modal)
[![Downloads](http://img.shields.io/packagist/dt/contao-bootstrap/modal.svg?style=flat-square)](http://packagist.com/packages/contao-bootstrap/modal)
[![Contao Community Alliance coding standard](http://img.shields.io/badge/cca-coding_standard-red.svg?style=flat-square)](https://github.com/contao-community-alliance/coding-standard)

This extension provides Bootstrap integration into Contao. 

Contao-Bootstrap is a modular integration. This extension provides the Bootstrap modal as frontend module.
