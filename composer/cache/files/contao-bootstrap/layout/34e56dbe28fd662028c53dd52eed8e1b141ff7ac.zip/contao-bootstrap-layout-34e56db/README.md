Contao-Bootstrap Layout
=====================

[![Build Status](http://img.shields.io/travis/contao-bootstrap/layout/master.svg?style=flat-square)](https://travis-ci.org/contao-bootstrap/layout)
[![Version](http://img.shields.io/packagist/v/contao-bootstrap/layout.svg?style=flat-square)](http://packagist.com/packages/contao-bootstrap/layout)
[![License](http://img.shields.io/packagist/l/contao-bootstrap/layout.svg?style=flat-square)](http://packagist.com/packages/contao-bootstrap/layout)
[![Downloads](http://img.shields.io/packagist/dt/contao-bootstrap/layout.svg?style=flat-square)](http://packagist.com/packages/contao-bootstrap/layout)
[![Contao Community Alliance coding standard](http://img.shields.io/badge/cca-coding_standard-red.svg?style=flat-square)](https://github.com/contao-community-alliance/coding-standard)

This extension provides Bootstrap integration into Contao. 

Contao-Bootstrap is a modular integration. The layout component allows to define a grid based layout using the 
backend layout editor.
