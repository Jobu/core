<?php

/*
 * content elements
 */

$GLOBALS['TL_LANG']['CTE']['bootstrap_accordionGroupEnd']['0']   = 'Akkordeon-Gruppe Ende';
$GLOBALS['TL_LANG']['CTE']['bootstrap_accordionGroupEnd']['1']   = 'Ende einer Akkordeongruppe';
$GLOBALS['TL_LANG']['CTE']['bootstrap_accordionGroupStart']['0'] = 'Akkordeon-Gruppe Anfang';
$GLOBALS['TL_LANG']['CTE']['bootstrap_accordionGroupStart']['1'] = 'Gruppiert einzelne Akkordeon Elemente und erzwingt ein geöffnetes Element.';

