<?php

/*
 * content elements
 */
$GLOBALS['TL_LANG']['CTE']['bootstrap_accordionGroupStart'][0] = 'Accordion Group start';
$GLOBALS['TL_LANG']['CTE']['bootstrap_accordionGroupStart'][1] = 'Groups all accordion elements and forcing merely one element to be opened.';
$GLOBALS['TL_LANG']['CTE']['bootstrap_accordionGroupEnd'][0]   = 'Accordion group end';
$GLOBALS['TL_LANG']['CTE']['bootstrap_accordionGroupEnd'][1]   = 'End of an accordion group';
