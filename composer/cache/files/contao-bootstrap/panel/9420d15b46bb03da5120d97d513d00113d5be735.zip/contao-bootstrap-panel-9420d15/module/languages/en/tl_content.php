<?php

$GLOBALS['TL_LANG']['tl_content']['bootstrap_collapseIn'][0] = 'Expand by default';
$GLOBALS['TL_LANG']['tl_content']['bootstrap_collapseIn'][1] = 'The panel is expanded by default.';
