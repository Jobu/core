<?php

/*
 * Fields
 */
$GLOBALS['TL_LANG']['tl_layout']['flexible_sections'][0]          = 'Eigene Layoutbereiche';
$GLOBALS['TL_LANG']['tl_layout']['flexible_sections'][1]          = 'Hier können Sie eigene Layoutbereiche definieren und einem Bereich zuweichen. Das Template muss diese Ausgabe unterstützen. Bei einem herkömmlichen Template werden die Layoutbereiche in einer Position gerendert.';
$GLOBALS['TL_LANG']['tl_layout']['flexible_sections_label'][0]    = 'Bezeichnung';
$GLOBALS['TL_LANG']['tl_layout']['flexible_sections_label'][1]    = 'Bezeichnung des Labels im Backend';
$GLOBALS['TL_LANG']['tl_layout']['flexible_sections_id'][0]       = 'ID';
$GLOBALS['TL_LANG']['tl_layout']['flexible_sections_id'][1]       = 'Eindeutiger Bezeichnung der Layoutbereiches';
$GLOBALS['TL_LANG']['tl_layout']['flexible_sections_template'][0] = 'Template';
$GLOBALS['TL_LANG']['tl_layout']['flexible_sections_template'][1] = 'Ausgabe kann über ein Template gesteuert werden.';
$GLOBALS['TL_LANG']['tl_layout']['flexible_sections_position'][0] = 'Position';
$GLOBALS['TL_LANG']['tl_layout']['flexible_sections_position'][1] = 'Position des Layoutbereichs';
$GLOBALS['TL_LANG']['tl_layout']['flexible_sections_class'][0]    = 'Css Klasse';
$GLOBALS['TL_LANG']['tl_layout']['flexible_sections_class'][1]    = 'Css Klasse des Layoutbereichs.';

/*
 * Values
 */
$GLOBALS['TL_LANG']['tl_layout']['custom'] = 'Manuelle Ausgabe';
