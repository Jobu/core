<?php

/*
 * Fields
 */
$GLOBALS['TL_LANG']['tl_layout']['flexible_sections'][0]          = 'Custom template sections';
$GLOBALS['TL_LANG']['tl_layout']['flexible_sections'][1]          = 'Define your custom template sections here. You can assign the section to a specific position. You have to use the fe_flexible_sections frontend to use this.';
$GLOBALS['TL_LANG']['tl_layout']['flexible_sections_label'][0]    = 'Label';
$GLOBALS['TL_LANG']['tl_layout']['flexible_sections_label'][1]    = 'Backend label.';
$GLOBALS['TL_LANG']['tl_layout']['flexible_sections_id'][0]       = 'ID';
$GLOBALS['TL_LANG']['tl_layout']['flexible_sections_id'][1]       = 'Unique identifier of the section';
$GLOBALS['TL_LANG']['tl_layout']['flexible_sections_template'][0] = 'Template';
$GLOBALS['TL_LANG']['tl_layout']['flexible_sections_template'][1] = 'Template being used for rendering.';
$GLOBALS['TL_LANG']['tl_layout']['flexible_sections_position'][0] = 'Position';
$GLOBALS['TL_LANG']['tl_layout']['flexible_sections_position'][1] = 'Position of the section.';
$GLOBALS['TL_LANG']['tl_layout']['flexible_sections_class'][0]    = 'Css class';
$GLOBALS['TL_LANG']['tl_layout']['flexible_sections_class'][1]    = 'Css class of custom section.';

/*
 * Values
 */
$GLOBALS['TL_LANG']['tl_layout']['custom'] = 'Manual output';
