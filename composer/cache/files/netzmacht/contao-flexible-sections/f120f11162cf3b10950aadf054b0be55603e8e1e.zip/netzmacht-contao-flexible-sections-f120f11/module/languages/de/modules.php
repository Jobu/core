<?php

$GLOBALS['TL_LANG']['MOD']['flexible-sections'][0] = 'Flexible Template Bereiche';
$GLOBALS['TL_LANG']['MOD']['flexible-sections'][1] = 'Flexible Template Bereiche';
