<?php

$GLOBALS['TL_LANG']['MOD']['flexible-sections'][0] = 'Flexible template sections';
$GLOBALS['TL_LANG']['MOD']['flexible-sections'][1] = 'Flexible template sections.';
