Contao Icon Wizard backend widget 
=================================

[![Build Status](http://img.shields.io/travis/netzmacht/contao-icon-wizard/master.svg?style=flat-square)](https://travis-ci.org/netzmacht/contao-icon-wizard)
[![Version](http://img.shields.io/packagist/v/netzmacht/contao-iconwizard.svg?style=flat-square)](http://packagist.com/packages/netzmacht/contao-icon-wizard)
[![License](http://img.shields.io/packagist/l/netzmacht/contao-iconwizard.svg?style=flat-square)](http://packagist.com/packages/netzmacht/contao-icon-wizard)
[![Downloads](http://img.shields.io/packagist/dt/netzmacht/contao-iconwizard.svg?style=flat-square)](http://packagist.com/packages/netzmacht/contao-icon-wizard)
[![Contao Community Alliance coding standard](http://img.shields.io/badge/cca-coding_standard-red.svg?style=flat-square)](https://github.com/contao-community-alliance/coding-standard)

Extension for Contao CMS which provides an iconWizard as backend widget.
