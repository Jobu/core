This is a pre-release nightly of sIFR 3 (r245 to be exact).  We (the SimplePie team) will be updating the 
sIFR code and font files from time to time as new releases of sIFR 3 are made available.

In this folder you'll find a few Flash 8 files.  The only one of you might want to mess with is sifr.fla.
  * Open it up
  * Double-click the rectangle in the middle
  * Select all
  * Change the font

More information about sIFR 3 can be found here:
  * http://dev.novemberborn.net/sifr3/
  * http://wiki.novemberborn.net/sifr3/